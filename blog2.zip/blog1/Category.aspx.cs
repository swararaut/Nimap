﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.IO;
public partial class About : System.Web.UI.Page
{
    SqlConnection conect;
    SqlCommand cmd;
    protected void Page_Load(object sender, EventArgs e)
    {
        string st;
        st = System.Configuration.ConfigurationManager.AppSettings["conect"];
        conect = new SqlConnection(st);
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        conect.Open();
        cmd = new SqlCommand("insert into Category(CategoryName) values(@n)", conect);
        cmd.Parameters.AddWithValue("@n", TextBox1.Text);
        cmd.ExecuteNonQuery();
        conect.Close();
        Response.Write("<script>alert('Category added successully')</script>");
    }
}
