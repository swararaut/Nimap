﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.IO;

public partial class _Default : System.Web.UI.Page
{
    SqlConnection conect;
    SqlCommand cmd;
    protected void Page_Load(object sender, EventArgs e)
    {
        string st;
        st = System.Configuration.ConfigurationManager.AppSettings["conect"];
        conect = new SqlConnection(st);
        display();

    }
    public void display()
    {
        conect.Open();
        cmd = new SqlCommand("select * from Product", conect);
        DataSet ds = new DataSet();
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        da.Fill(ds);

        GridView2.DataBind();
        conect.Close();
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        conect.Open();
        cmd = new SqlCommand("insert into Product(ProductName,catid) values(@p,@Id)", conect);
        cmd.Parameters.AddWithValue("@p", TextBox1.Text);
        cmd.Parameters.AddWithValue("@Id", DropDownList1.SelectedValue );
        cmd.ExecuteNonQuery();
        conect.Close();
        Response.Write("<script>alert('product added successully')</script>");
        display();
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        conect.Open();
        cmd = new SqlCommand("Update Product Set ProductName=@p,catid=@Id Where ProductId=@sa ", conect);
        cmd.Parameters.AddWithValue("@sa", System.Convert.ToInt64(Label4.Text));
        cmd.Parameters.AddWithValue("@p", TextBox1.Text);
        cmd.Parameters.AddWithValue("@Id", DropDownList1.Text);
        cmd.ExecuteNonQuery();
        conect.Close();
        Response.Write("<script>alert('product Update successully')</script>");
        display();

    }
    protected void GridView2_SelectedIndexChanged(object sender, EventArgs e)
    {
        Label4.Text = GridView2.SelectedRow.Cells[1].Text;
        TextBox1.Text = GridView2.SelectedRow.Cells[2].Text;
        DropDownList1.Text = GridView2.SelectedRow.Cells[3].Text;
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        conect.Open();
        cmd = new SqlCommand("delete from Product where ProductId=@sa ", conect);
        cmd.Parameters.AddWithValue("@sa", System.Convert.ToInt32(Label4.Text));
        cmd.ExecuteNonQuery();
        conect.Close();
        Response.Write("<script>alert('product delete successully')</script>");
        display();
    }
}
